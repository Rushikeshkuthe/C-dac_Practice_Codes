﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoMVC.Models
{
    public class Person
    {
        public int No { get; set; }
        public string Name { get; set; }
    }
}