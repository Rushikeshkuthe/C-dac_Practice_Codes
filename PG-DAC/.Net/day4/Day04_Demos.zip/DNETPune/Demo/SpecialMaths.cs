﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Arithmatic;
namespace Demo
{
    public class SpecialMaths : Maths
    {
    }
}