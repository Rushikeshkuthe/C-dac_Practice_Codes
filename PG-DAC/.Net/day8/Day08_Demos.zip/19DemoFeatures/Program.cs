﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19DemoFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Partial Class Concept
            //Maths obj = new Maths();
            #endregion

            #region Nullable Type

            //int? i = null;
            //Nullable<int> i = null;

            //if (i.HasValue)
            //{
            //    Console.WriteLine("i holds a value "+ i.ToString());
            //}
            //else
            //{
            //    Console.WriteLine("i holds NULL");
            //}
            #endregion


        }
    }
}
