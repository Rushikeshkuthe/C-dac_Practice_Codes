﻿--create table Test(No int primary key, Name varchar(50))

--insert into Test values(1, 'mahesh')
--insert into Test values(2, 'nilesh')
--insert into Test values(3, 'suresh')

select * from Test